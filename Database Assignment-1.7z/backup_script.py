import mysql.connector
import subprocess
import os
from datetime import datetime
import logging

# Configure logging for debugging and tracking
logging.basicConfig(level=logging.INFO, format='  format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_backup(host, user, password, database, backup_dir):
    """
    Create a MySQL database backup using mysqldump.

    Args:
        host (str): MySQL host address (e.g., 'localhost')
        user (str): MySQL username
        password (str): MySQL password
        database (str): Database name to backup
        backup_dir (str): Directory to store backup files

    Returns:
        str: Path to the created backup file

    Raises:
        mysql.connector.Error: If database connection fails
        subprocess.CalledProcessError: If mysqldump command fails
        Exception: For other unexpected errors
    """
    try:
        # Step 1: Verify database connection
        conn = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        conn.close()
        logger.info(f"Successfully connected to database: {database}")

        # Step 2: Ensure backup directory exists
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
            logger.info(f"Created backup directory: {backup_dir}")

        # Step 3: Generate unique filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        backup_file = os.path.join(backup_dir, f"{database}_{timestamp}.sql")

        # Step 4: Construct mysqldump command
        dump_cmd = [
            "mysqldump",
            f"--host={host}",
            f"--user={user}",
            f"--password={password}",
            database
        ]

        # Step 5: Execute backup command and save to file
        with open(backup_file, 'w') as f:
            process = subprocess.run(dump_cmd, stdout=f, text=True, check=True)
            logger.info(f"Backup created successfully: {backup_file}")

        # Step 6: Verify backup file exists
        if os.path.exists(backup_file) and os.path.getsize(backup_file) > 0:
            return backup_file
        else:
            raise Exception("Backup file is empty or was not created")

    except mysql.connector.Error as e:
        logger.error(f"Database connection error: {e}")
        raise
    except subprocess.CalledProcessError as e:
        logger.error(f"Backup failed: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise

if __name__ == "__main__":
    # Example configuration (replace with actual credentials)
    config = {
        "host": "localhost",
        "user": "root",
        "password": "your_password",
        "database": "mydb",
        "backup_dir": "./backups"
    }

    try:
        backup_path = create_backup(**config)
        logger.info(f"Backup completed: {backup_path}")
    except Exception as e:
        logger.error(f"Backup process failed: {e}")